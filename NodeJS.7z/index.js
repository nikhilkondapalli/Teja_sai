const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const { mongoose } = require('./db.js');
var employeeController = require('./controllers/employeeController.js');
var ProductController = require('./controllers/ProductController.js');
var FundsController = require('./controllers/FundsController.js')
var OrdersController = require('./controllers/OrderController.js')

var app = express();
app.use(bodyParser.json());
app.use(cors({ origin: 'http://localhost:4200' }));

app.listen(3000, () => console.log('Server started at port : 3000'));

app.use('/RaiseTicket', employeeController);
app.use('/Product', ProductController);
app.use('/funds', FundsController);
app.use('/orders', OrdersController);