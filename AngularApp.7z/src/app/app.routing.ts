import { Routes, RouterModule } from '@angular/router';

import { CartComponent } from './shopping/cart/cart.component';
import { ProductComponent } from './shopping/product/product.component';
import { EmployeeComponent } from '../app/Employee/employee.component'
const routes: Routes = [
  { path: 'RaiseTicket', component: EmployeeComponent },
  { path: 'products', component: ProductComponent },
  { path: 'cart', component: CartComponent },
  { path: '**', redirectTo: '' }
];

export const routing = RouterModule.forRoot(routes);
