
export class Funds {

  _id: string;
  id: number;
  funds: number;
  emailid: string;

}
