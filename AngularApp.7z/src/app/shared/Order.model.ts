
export class Order {

  _id: string = " ";
  emailid: string = " ";
  Amount: number = 0;
  status: string = "";

}
