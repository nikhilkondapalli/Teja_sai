export class Employee {
    _id: string;
    UserEmail: string;
    Reason: string;
    
}
