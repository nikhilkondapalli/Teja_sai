import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { EmployeeComponent } from './employee/employee.component';
import { ShoppingComponent } from './Shopping/shopping.component';
import { ProductComponent } from './Shopping/Product/product.component';
import { CartComponent } from './Shopping/cart/cart.component';
import { Routes, RouterModule } from '@angular/router';
import { ProductService } from './shared/product.service';
import { FundsService } from './shared/funds.service';
const routes: Routes = [
  { path: 'RaiseTicket', component: EmployeeComponent },
  { path: 'Shopping', component: ShoppingComponent },

  { path: 'products', component: ProductComponent },
  { path: 'cart', component: CartComponent },
  { path: '**', redirectTo: '' }
];
@NgModule({
  declarations: [
    AppComponent,
    EmployeeComponent,
    ShoppingComponent,
    ProductComponent,
    CartComponent,
    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(routes),
  ],
  exports: [RouterModule],
  providers: [ProductService, FundsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
